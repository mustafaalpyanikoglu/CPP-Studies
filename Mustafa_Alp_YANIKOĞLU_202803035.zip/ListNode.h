struct Node // listede bulunacak herbir elmanın tipi
{
    int deger;
    Node *sonraki;
};